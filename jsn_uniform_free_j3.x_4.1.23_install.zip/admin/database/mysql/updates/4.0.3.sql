ALTER TABLE `#__jsn_uniform_templates` ADD `template_from_name` VARCHAR(255) NOT NULL DEFAULT '';

