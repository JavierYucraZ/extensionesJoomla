var JSNES_Underscore = _;

var JSNES_jQuery = jQuery;
//
//var JSNES_Backbone = Backbone.noConflict();
//var JSNES_jQuery = $;

var JSNES_Backbone = Backbone;
