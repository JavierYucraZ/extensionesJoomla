DROP TABLE IF EXISTS `#__jsn_easyslider_config`;
DROP TABLE IF EXISTS `#__jsn_easyslider_messages`;
DROP TABLE IF EXISTS `#__jsn_easyslider_sliders`;
