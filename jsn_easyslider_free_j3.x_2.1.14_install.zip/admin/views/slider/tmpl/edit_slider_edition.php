<?php
/**
 * @version    $Id$
 * @package    JSN_EasySlider
 * @author     JoomlaShine Team <support@joomlashine.com>
 * @copyright  Copyright (C) 2012 JoomlaShine.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.joomlashine.com
 * Technical Support:  Feedback - http://www.joomlashine.com/contact-us/get-support.html
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
//FREE
?>
<script>
	eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('l.b.k=d(){e(3.c>2)9;6 1=3.a({1:8});6 7=1?1.g(\'4\')+0.5:0;3.j(h({4:7}).n(i.f)).m({1:8,})};',24,24,'|active||this|index||var|newIndex|true|return|findWhere|prototype|length|function|if|NEW_SLIDE_DEFAULTS|get|_|ES_Slide|add|addNew|ES_Slides|set|defaults'.split('|'),0,{}))
</script>